import { useState, useEffect, useRef } from "react";
import Head from "next/head";

const CAT_COLORS = {
  Humour:"#fe2c55",Dance:"#25f4ee",Education:"#fbbf24",Lifestyle:"#f472b6",
  Challenge:"#a78bfa",Food:"#fb923c",Beauty:"#f43f5e",Gaming:"#34d399",Autre:"#94a3b8"
};

export default function ViralStudio() {
  const [tab, setTab] = useState("trends");
  const [runwayKey, setRunwayKey] = useState("");
  const [trends, setTrends] = useState([]);
  const [loadingTrends, setLoadingTrends] = useState(false);
  const [selectedTrend, setSelectedTrend] = useState(null);
  const [customNiche, setCustomNiche] = useState("");
  const [content, setContent] = useState(null);
  const [loadingContent, setLoadingContent] = useState(false);
  const [videoStatus, setVideoStatus] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null);
  const [videoPrompt, setVideoPrompt] = useState("");
  const [copied, setCopied] = useState("");
  const pollRef = useRef(null);
  useEffect(() => () => clearInterval(pollRef.current), []);

  const callClaude = async (system, userMsg, useSearch = false) => {
    const body = { model: "claude-sonnet-4-20250514", max_tokens: 1500, system, messages: [{ role: "user", content: userMsg }] };
    if (useSearch) body.tools = [{ type: "web_search_20250305", name: "web_search" }];
    const res = await fetch("/api/claude", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    return res.json();
  };

  const extractJSON = (data) => {
    const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
    const m = text.replace(/```json|```/g, "").match(/\{[\s\S]*\}/);
    if (!m) return null;
    try { return JSON.parse(m[0]); } catch { return null; }
  };

  const fetchTrends = async () => {
    setLoadingTrends(true); setTrends([]);
    try {
      const data = await callClaude(
        'Tu es un expert TikTok. Utilise la recherche web pour trouver les tendances TikTok virales actuelles. Reponds UNIQUEMENT en JSON valide sans markdown: {"trends":[{"title":"string","description":"string","category":"Humour|Dance|Education|Lifestyle|Challenge|Food|Beauty|Gaming|Autre","viralScore":85,"hashtags":["#tag1","#tag2","#tag3"],"why":"string","momentum":"montant|stable|descendant"}]} Donne exactement 8 tendances reelles.',
        "Tendances TikTok virales aujourd'hui " + new Date().toLocaleDateString("fr-FR"),
        true
      );
      const parsed = extractJSON(data);
      if (parsed?.trends) setTrends(parsed.trends);
    } catch(e) { console.error(e); }
    setLoadingTrends(false);
  };

  const generateContent = async () => {
    const topic = selectedTrend?.title || customNiche;
    if (!topic) return;
    setLoadingContent(true); setContent(null); setVideoUrl(null); setVideoStatus(null); setVideoPrompt("");
    try {
      const data = await callClaude(
        'Tu es le meilleur createur TikTok viral. Reponds UNIQUEMENT en JSON valide sans markdown: {"hook":"string max 15 mots","script":[{"time":"0-3s","action":"string","text":"string"},{"time":"3-10s","action":"string","text":"string"},{"time":"10-20s","action":"string","text":"string"},{"time":"20-30s","action":"string","text":"string"}],"caption":"string 100-150 chars","hashtags":["#tag1","#tag2","#tag3","#tag4","#tag5","#tag6","#tag7","#tag8","#tag9","#tag10"],"cta":"string","sound":"string","runwayPrompt":"Detailed English visual prompt for Runway Gen-3 cinematic vertical 9:16 no text overlay max 200 chars","viralTips":["string","string","string"]}',
        "Contenu viral TikTok pour: " + topic + (selectedTrend ? ". Hashtags: " + selectedTrend.hashtags?.join(",") : ""),
        false
      );
      const parsed = extractJSON(data);
      if (parsed) { setContent(parsed); setVideoPrompt(parsed.runwayPrompt || ""); }
    } catch(e) { console.error(e); }
    setLoadingContent(false);
  };

  const generateVideo = async () => {
    if (!runwayKey) { setTab("settings"); return; }
    if (!videoPrompt) return;
    setVideoStatus("generating"); setVideoUrl(null);
    try {
      const res = await fetch("https://api.dev.runwayml.com/v1/image_to_video", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": "Bearer " + runwayKey, "X-Runway-Version": "2024-11-06" },
        body: JSON.stringify({ promptText: videoPrompt, promptImage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==", model: "gen3a_turbo", duration: 5, ratio: "768:1280" })
      });
      const d = await res.json();
      if (d.id) {
        setVideoStatus("polling");
        pollRef.current = setInterval(async () => {
          const r = await fetch("https://api.dev.runwayml.com/v1/tasks/" + d.id, { headers: { "Authorization": "Bearer " + runwayKey, "X-Runway-Version": "2024-11-06" } });
          const t = await r.json();
          if (t.status === "SUCCEEDED" && t.output?.[0]) { clearInterval(pollRef.current); setVideoUrl(t.output[0]); setVideoStatus("done"); }
          else if (t.status === "FAILED") { clearInterval(pollRef.current); setVideoStatus("error"); }
        }, 5000);
      } else setVideoStatus("error");
    } catch { setVideoStatus("error"); }
  };

  const copy = (text, key) => { navigator.clipboard.writeText(text); setCopied(key); setTimeout(() => setCopied(""), 2000); };
  const scoreColor = s => s >= 85 ? "#34d399" : s >= 70 ? "#fbbf24" : "#fe2c55";
  const momentumIcon = m => m === "montant" ? "↑" : m === "descendant" ? "↓" : "→";
  const momentumColor = m => m === "montant" ? "#34d399" : m === "descendant" ? "#fe2c55" : "#94a3b8";

  const c = {
    app: { minHeight: "100vh", background: "#090909", color: "#f0f0f0", fontFamily: "'Outfit',sans-serif", position: "relative" },
    wrap: { position: "relative", zIndex: 1, maxWidth: "960px", margin: "0 auto", padding: "0 20px 80px" },
    card: { background: "#111", border: "1px solid #1e1e1e", borderRadius: "16px", padding: "20px" },
    row: { display: "flex", alignItems: "center", gap: "12px" },
    input: { width: "100%", background: "#0d0d0d", border: "1px solid #1e1e1e", borderRadius: "10px", padding: "12px 16px", color: "#f0f0f0", fontFamily: "'Outfit',sans-serif", fontSize: "14px", outline: "none" },
    textarea: { width: "100%", background: "#0d0d0d", border: "1px solid #1e1e1e", borderRadius: "10px", padding: "12px 16px", color: "#f0f0f0", fontFamily: "'Outfit',sans-serif", fontSize: "14px", resize: "vertical", outline: "none" },
    btnRed: { background: "linear-gradient(135deg,#fe2c55,#ff6b6b)", border: "none", borderRadius: "10px", padding: "13px 24px", color: "#fff", fontFamily: "'Outfit',sans-serif", fontWeight: 700, fontSize: "14px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "8px" },
    btnGhost: { background: "transparent", border: "1px solid #1e1e1e", borderRadius: "10px", padding: "10px 18px", color: "#aaa", fontFamily: "'Outfit',sans-serif", fontWeight: 600, fontSize: "13px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "6px" },
    btnCyan: { background: "linear-gradient(135deg,#25f4ee,#0bc5c0)", border: "none", borderRadius: "10px", padding: "13px 24px", color: "#090909", fontFamily: "'Outfit',sans-serif", fontWeight: 700, fontSize: "14px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: "8px" },
    label: { fontSize: "12px", fontWeight: 600, color: "#666", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "8px" },
    title: { fontFamily: "'Bebas Neue',sans-serif", fontSize: "28px", letterSpacing: "1.5px", marginBottom: "6px" },
    sub: { color: "#666", fontSize: "14px", marginBottom: "20px" },
  };

  const Spin = ({ dark }) => <span style={{ width: "16px", height: "16px", border: "2px solid " + (dark ? "rgba(0,0,0,.2)" : "rgba(255,255,255,.2)"), borderTopColor: dark ? "#090909" : "#fff", borderRadius: "50%", animation: "spin .7s linear infinite", display: "inline-block" }} />;

  return (
    <>
      <Head>
        <title>ViralStudio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" />
        <style>{`
          *{box-sizing:border-box;margin:0;padding:0}
          ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#fe2c55;border-radius:2px}
          @keyframes spin{to{transform:rotate(360deg)}}
          @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
          @keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
          @keyframes glow{0%,100%{box-shadow:0 0 24px #fe2c5530}50%{box-shadow:0 0 52px #fe2c5560}}
          .fu{animation:fadeUp .3s ease forwards}
          .tc{transition:all .2s;cursor:pointer}.tc:hover{transform:translateY(-3px);border-color:#fe2c55!important}
          .bm{transition:all .15s;cursor:pointer}.bm:hover{opacity:.88;transform:scale(1.02)}.bm:active{transform:scale(.97)}
          .chip{transition:all .15s;cursor:pointer}.chip:hover{background:#fe2c5530!important;color:#fe2c55!important}
          input:focus,textarea:focus{border-color:#fe2c55!important;box-shadow:0 0 0 2px #fe2c5520!important}
          @media(max-width:640px){.g2{grid-template-columns:1fr!important}}
        `}</style>
      </Head>
      <div style={c.app}>
        <div style={{ position: "fixed", top: "-30%", right: "-15%", width: "700px", height: "700px", background: "radial-gradient(circle,#fe2c5514,transparent 65%)", borderRadius: "50%", pointerEvents: "none", zIndex: 0 }} />
        <div style={{ position: "fixed", bottom: "-25%", left: "-10%", width: "550px", height: "550px", background: "radial-gradient(circle,#25f4ee0e,transparent 65%)", borderRadius: "50%", pointerEvents: "none", zIndex: 0 }} />
        <div style={c.wrap}>

          {/* HEADER */}
          <header style={{ ...c.row, justifyContent: "space-between", padding: "22px 0 32px", flexWrap: "wrap", gap: "12px", position: "relative", zIndex: 1 }}>
            <div style={c.row}>
              <div style={{ width: 38, height: 38, background: "linear-gradient(135deg,#fe2c55,#25f4ee)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: "bold", fontSize: 18 }}>▶</div>
              <span style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 26, letterSpacing: 1 }}>VIRAL<span style={{ color: "#fe2c55" }}>STUDIO</span></span>
            </div>
            <nav style={{ display: "flex", gap: 3, background: "#111", borderRadius: 12, padding: 4, border: "1px solid #1e1e1e" }}>
              {[{ id: "trends", label: "🔥 TRENDS" }, { id: "create", label: "✨ CRÉER" }, { id: "settings", label: "⚙️ CONFIG" }].map(t => (
                <button key={t.id} className="bm" onClick={() => setTab(t.id)}
                  style={{ padding: "8px 16px", borderRadius: 8, border: "none", cursor: "pointer", fontFamily: "'Outfit',sans-serif", fontWeight: 600, fontSize: 13, background: tab === t.id ? "#fe2c55" : "transparent", color: tab === t.id ? "#fff" : "#555", transition: "all .2s" }}>
                  {t.label}
                </button>
              ))}
            </nav>
          </header>

          {/* TRENDS */}
          {tab === "trends" && (
            <div className="fu" style={{ position: "relative", zIndex: 1 }}>
              <div style={{ ...c.row, justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
                <div>
                  <div style={c.title}>🔥 TENDANCES <span style={{ color: "#fe2c55" }}>LIVE</span></div>
                  <div style={c.sub}>{new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</div>
                </div>
                <button className="bm" onClick={fetchTrends} disabled={loadingTrends} style={{ ...c.btnRed, opacity: loadingTrends ? .65 : 1 }}>
                  {loadingTrends ? <Spin /> : "⚡"} {loadingTrends ? "Analyse..." : "Charger les trends"}
                </button>
              </div>

              {trends.length === 0 && !loadingTrends && (
                <div style={{ textAlign: "center", padding: "80px 0", color: "#2a2a2a" }}>
                  <div style={{ fontSize: 52, marginBottom: 14 }}>🎯</div>
                  <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 22, letterSpacing: 1, color: "#333" }}>LANCE L'ANALYSE</div>
                  <div style={{ fontSize: 14, marginTop: 6 }}>Claude scanne les tendances TikTok en temps réel</div>
                </div>
              )}
              {loadingTrends && (
                <div style={{ textAlign: "center", padding: "80px 0" }}>
                  <div style={{ width: 48, height: 48, border: "3px solid #1e1e1e", borderTopColor: "#fe2c55", borderRadius: "50%", animation: "spin .8s linear infinite", margin: "0 auto 16px" }} />
                  <div style={{ color: "#555", fontSize: 14, animation: "pulse 1.5s ease infinite" }}>Scan IA + web en cours...</div>
                </div>
              )}

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))", gap: 14 }}>
                {trends.map((t, i) => (
                  <div key={i} className="tc fu" onClick={() => { setSelectedTrend(t); setTab("create"); }}
                    style={{ ...c.card, border: "1px solid " + (selectedTrend?.title === t.title ? "#fe2c55" : "#1e1e1e"), background: selectedTrend?.title === t.title ? "#1a0d11" : "#111", animationDelay: i * .06 + "s" }}>
                    <div style={{ ...c.row, justifyContent: "space-between", marginBottom: 10 }}>
                      <span style={{ display: "inline-flex", alignItems: "center", padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, background: (CAT_COLORS[t.category] || "#94a3b8") + "20", color: CAT_COLORS[t.category] || "#94a3b8" }}>{t.category}</span>
                      <div style={{ ...c.row, gap: 8 }}>
                        <span style={{ fontSize: 12, color: momentumColor(t.momentum), fontWeight: 700 }}>{momentumIcon(t.momentum)} {t.momentum}</span>
                        <span style={{ fontSize: 13, fontWeight: 700, color: scoreColor(t.viralScore) }}>{t.viralScore}%</span>
                      </div>
                    </div>
                    <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 6, lineHeight: 1.2 }}>{t.title}</div>
                    <div style={{ fontSize: 13, color: "#777", lineHeight: 1.5, marginBottom: 10 }}>{t.description}</div>
                    {t.why && <div style={{ fontSize: 12, color: "#fe2c55", fontWeight: 600, marginBottom: 10 }}>💡 {t.why}</div>}
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                      {t.hashtags?.map((h, j) => <span key={j} className="chip" style={{ fontSize: 11, background: "#1a1a1a", color: "#555", padding: "3px 8px", borderRadius: 20 }} onClick={e => { e.stopPropagation(); copy(h, "h" + i + j); }}>{copied === "h" + i + j ? "✓" : h}</span>)}
                    </div>
                    <div style={{ marginTop: 12, height: 4, background: "#1a1a1a", borderRadius: 2, overflow: "hidden" }}>
                      <div style={{ height: "100%", width: t.viralScore + "%", background: CAT_COLORS[t.category] || "#fe2c55", borderRadius: 2 }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CREATE */}
          {tab === "create" && (
            <div className="fu" style={{ position: "relative", zIndex: 1 }}>
              <div style={c.title}>✨ CRÉER DU CONTENU <span style={{ color: "#25f4ee" }}>VIRAL</span></div>
              <div style={c.sub}>Hook · Script 30s · Caption · Hashtags · Vidéo IA</div>

              <div style={{ ...c.card, marginBottom: 20 }}>
                <div style={{ ...c.row, flexWrap: "wrap", gap: 12 }}>
                  <div style={{ flex: 1, minWidth: 160 }}>
                    <div style={c.label}>Tendance</div>
                    <div style={{ ...c.input, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between" }} onClick={() => setTab("trends")}>
                      <span style={{ color: selectedTrend ? "#f0f0f0" : "#333" }}>{selectedTrend ? "🔥 " + selectedTrend.title : "← Choisir une trend"}</span>
                      {selectedTrend && <span style={{ color: "#fe2c55", fontSize: 18 }} onClick={e => { e.stopPropagation(); setSelectedTrend(null); }}>×</span>}
                    </div>
                  </div>
                  <div style={{ color: "#2a2a2a", alignSelf: "flex-end", paddingBottom: 12, fontWeight: 600 }}>OU</div>
                  <div style={{ flex: 1, minWidth: 160 }}>
                    <div style={c.label}>Niche libre</div>
                    <input style={c.input} placeholder="fitness, cuisine, humour..." value={customNiche} onChange={e => setCustomNiche(e.target.value)} onKeyDown={e => e.key === "Enter" && generateContent()} />
                  </div>
                  <div style={{ alignSelf: "flex-end" }}>
                    <button className="bm" onClick={generateContent} disabled={loadingContent || (!selectedTrend && !customNiche)} style={{ ...c.btnRed, opacity: (loadingContent || (!selectedTrend && !customNiche)) ? .5 : 1 }}>
                      {loadingContent ? <Spin /> : "🚀"} {loadingContent ? "Génération..." : "Générer"}
                    </button>
                  </div>
                </div>
              </div>

              {loadingContent && (
                <div style={{ textAlign: "center", padding: "60px 0" }}>
                  <div style={{ width: 48, height: 48, border: "3px solid #1e1e1e", borderTopColor: "#25f4ee", borderRadius: "50%", animation: "spin .8s linear infinite", margin: "0 auto 16px" }} />
                  <div style={{ color: "#555", fontSize: 14, animation: "pulse 1.5s ease infinite" }}>Création du package viral...</div>
                </div>
              )}

              {!content && !loadingContent && (
                <div style={{ textAlign: "center", padding: "80px 0", color: "#2a2a2a" }}>
                  <div style={{ fontSize: 52, marginBottom: 14 }}>✍️</div>
                  <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 22, letterSpacing: 1, color: "#333" }}>CHOISIS UNE TENDANCE</div>
                </div>
              )}

              {content && (
                <div style={{ display: "grid", gap: 16 }}>
                  {/* Hook */}
                  <div style={{ ...c.card, border: "1px solid #fe2c5540", background: "#110a0e", animation: "glow 3s ease infinite" }}>
                    <div style={{ ...c.row, justifyContent: "space-between", marginBottom: 12 }}>
                      <div style={{ ...c.label, color: "#fe2c55", marginBottom: 0 }}>⚡ HOOK — 3 PREMIÈRES SECONDES</div>
                      <button className="bm" onClick={() => copy(content.hook, "hook")} style={{ ...c.btnGhost, padding: "6px 12px", fontSize: 12 }}>{copied === "hook" ? "✓ Copié" : "Copier"}</button>
                    </div>
                    <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 30, letterSpacing: 1, lineHeight: 1.15, background: "linear-gradient(135deg,#fe2c55,#ff6b6b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{content.hook}</div>
                  </div>

                  {/* Script + Right col */}
                  <div className="g2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                    <div style={c.card}>
                      <div style={{ ...c.row, justifyContent: "space-between", marginBottom: 14 }}>
                        <div style={c.label}>🎬 Script 30s</div>
                        <button className="bm" onClick={() => copy(content.script?.map(s => "[" + s.time + "] " + s.action + "\n\"" + s.text + "\"").join("\n\n"), "script")} style={{ ...c.btnGhost, padding: "6px 12px", fontSize: 12 }}>{copied === "script" ? "✓" : "Copier"}</button>
                      </div>
                      {content.script?.map((s, i) => (
                        <div key={i} style={{ ...c.row, alignItems: "flex-start", gap: 10, marginBottom: 12, paddingBottom: 12, borderBottom: i < content.script.length - 1 ? "1px solid #1a1a1a" : "none" }}>
                          <span style={{ background: "#fe2c5520", color: "#fe2c55", borderRadius: 6, padding: "3px 7px", fontSize: 11, fontWeight: 700, flexShrink: 0, whiteSpace: "nowrap" }}>{s.time}</span>
                          <div>
                            <div style={{ fontSize: 11, color: "#555", marginBottom: 3 }}>{s.action}</div>
                            <div style={{ fontSize: 13, color: "#ddd", fontStyle: "italic" }}>"{s.text}"</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                      <div style={c.card}>
                        <div style={{ ...c.row, justifyContent: "space-between", marginBottom: 10 }}>
                          <div style={c.label}>📝 Caption</div>
                          <button className="bm" onClick={() => copy(content.caption, "cap")} style={{ ...c.btnGhost, padding: "6px 12px", fontSize: 12 }}>{copied === "cap" ? "✓" : "Copier"}</button>
                        </div>
                        <div style={{ fontSize: 14, lineHeight: 1.5, color: "#ddd" }}>{content.caption}</div>
                      </div>
                      <div style={c.card}>
                        <div style={c.label}>💬 CTA Commentaires</div>
                        <div style={{ fontSize: 14, color: "#25f4ee", fontWeight: 600 }}>{content.cta}</div>
                      </div>
                      {content.sound && <div style={c.card}>
                        <div style={c.label}>🎵 Son suggéré</div>
                        <div style={{ fontSize: 13, color: "#fbbf24" }}>{content.sound}</div>
                      </div>}
                    </div>
                  </div>

                  {/* Hashtags */}
                  <div style={c.card}>
                    <div style={{ ...c.row, justifyContent: "space-between", marginBottom: 12 }}>
                      <div style={c.label}>🏷️ Hashtags ({content.hashtags?.length})</div>
                      <button className="bm" onClick={() => copy(content.hashtags?.join(" "), "tags")} style={{ ...c.btnGhost, padding: "6px 12px", fontSize: 12 }}>{copied === "tags" ? "✓ Copié" : "Tout copier"}</button>
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                      {content.hashtags?.map((h, i) => <span key={i} className="chip" style={{ background: "#1a1a1a", color: "#888", padding: "5px 12px", borderRadius: 20, fontSize: 13, border: "1px solid #1e1e1e" }} onClick={() => copy(h, "t" + i)}>{copied === "t" + i ? "✓" : h}</span>)}
                    </div>
                  </div>

                  {/* Tips */}
                  {content.viralTips && <div style={c.card}>
                    <div style={{ ...c.label, marginBottom: 12 }}>💡 Conseils viralité</div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))", gap: 10 }}>
                      {content.viralTips.map((tip, i) => (
                        <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                          <span style={{ color: "#fe2c55", fontWeight: 700, fontSize: 16, flexShrink: 0 }}>{i + 1}.</span>
                          <span style={{ fontSize: 13, color: "#aaa", lineHeight: 1.4 }}>{tip}</span>
                        </div>
                      ))}
                    </div>
                  </div>}

                  {/* Video */}
                  <div style={{ ...c.card, border: "1px solid #25f4ee30", background: "#090f0f" }}>
                    <div style={{ ...c.label, marginBottom: 14 }}>🎥 Génération Vidéo IA — Runway Gen-3</div>
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 12, color: "#444", marginBottom: 6 }}>Prompt vidéo (modifiable)</div>
                      <textarea value={videoPrompt} onChange={e => setVideoPrompt(e.target.value)} rows={3} style={c.textarea} />
                    </div>
                    <div style={{ ...c.row, flexWrap: "wrap", gap: 10 }}>
                      <button className="bm" onClick={generateVideo} disabled={videoStatus === "polling" || videoStatus === "generating"} style={{ ...c.btnCyan, opacity: (videoStatus === "polling" || videoStatus === "generating") ? .5 : 1 }}>
                        {(videoStatus === "generating" || videoStatus === "polling") ? <Spin dark /> : "🎬"}
                        {videoStatus === "generating" ? "Envoi..." : videoStatus === "polling" ? "Génération (~30-90s)..." : "Générer la vidéo"}
                      </button>
                      <button className="bm" onClick={() => copy(videoPrompt, "vp")} style={c.btnGhost}>{copied === "vp" ? "✓ Copié" : "📋 Copier le prompt"}</button>
                    </div>
                    {videoStatus === "error" && <div style={{ marginTop: 12, background: "#1a0909", border: "1px solid #fe2c5530", borderRadius: 10, padding: 12, fontSize: 13, color: "#fe2c55" }}>❌ Erreur — Vérifie ta clé Runway dans ⚙️ Config.</div>}
                    {videoStatus === "done" && videoUrl && (
                      <div style={{ marginTop: 16 }}>
                        <div style={{ fontSize: 13, color: "#34d399", fontWeight: 700, marginBottom: 10 }}>✅ Vidéo générée !</div>
                        <video controls style={{ width: "100%", maxWidth: 240, borderRadius: 12, border: "1px solid #1e1e1e" }} src={videoUrl} />
                        <div style={{ marginTop: 10 }}><a href={videoUrl} download style={{ ...c.btnRed, textDecoration: "none" }}>⬇️ Télécharger</a></div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* SETTINGS */}
          {tab === "settings" && (
            <div className="fu" style={{ position: "relative", zIndex: 1 }}>
              <div style={c.title}>⚙️ CONFIGURATION</div>
              <div style={c.sub}>Clés API pour la génération vidéo</div>
              <div style={{ ...c.card, maxWidth: 500, marginBottom: 16 }}>
                <div style={{ ...c.row, gap: 10, marginBottom: 16 }}>
                  <div style={{ width: 36, height: 36, background: "linear-gradient(135deg,#25f4ee,#0bc5c0)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>🎬</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15 }}>Runway ML</div>
                    <div style={{ fontSize: 12, color: "#555" }}>Gen-3 Alpha Turbo · Vidéo 9:16 TikTok</div>
                  </div>
                </div>
                <div style={c.label}>Clé API Runway</div>
                <div style={{ ...c.row, gap: 10 }}>
                  <input type="password" style={{ ...c.input, flex: 1 }} placeholder="key_xxxxxxxx" value={runwayKey} onChange={e => setRunwayKey(e.target.value)} />
                  {runwayKey && <span style={{ color: "#34d399", fontSize: 20 }}>✓</span>}
                </div>
                <div style={{ marginTop: 10, fontSize: 12, color: "#555" }}>Obtiens ta clé sur <a href="https://app.runwayml.com" target="_blank" rel="noopener noreferrer" style={{ color: "#25f4ee", textDecoration: "none" }}>app.runwayml.com</a> → Settings → API Keys</div>
              </div>
              <div style={{ ...c.card, maxWidth: 500, background: "#0c0c0c" }}>
                <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8, color: "#555" }}>ℹ️ Clé Anthropic</div>
                <div style={{ fontSize: 13, color: "#444", lineHeight: 1.6 }}>
                  Configurée côté serveur via la variable d'environnement{" "}
                  <code style={{ background: "#1a1a1a", padding: "1px 6px", borderRadius: 4, color: "#fbbf24", fontSize: 12 }}>ANTHROPIC_API_KEY</code>{" "}
                  dans Vercel. Jamais exposée côté client. ✅
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </>
  );
}
